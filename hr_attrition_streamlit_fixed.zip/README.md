
# HR Attrition Intelligence — Streamlit App (Fixed)

This fixed version includes the correct dependencies for Streamlit Cloud (with Plotly).

## Requirements
```
streamlit
pandas
numpy
plotly
scikit-learn
```

## Quick Deploy Steps
1. Upload all files (`app.py`, `requirements.txt`, `README.md`, `hr_sample_attrition.csv`) to a **GitHub repo root**.
2. On Streamlit Cloud, select the repo and set entry point to `app.py`.
3. Wait for Streamlit Cloud to install packages automatically and launch the app.
