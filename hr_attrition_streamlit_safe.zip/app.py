
import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split, StratifiedKFold, cross_val_score
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix, roc_curve, auc

st.set_page_config(page_title="HR Attrition Intelligence", layout="wide")

st.title("🧭 HR Attrition Intelligence — Streamlit Dashboard (Safe Matplotlib Version)")

DEFAULT_FILE = "hr_sample_attrition.csv"

@st.cache_data
def load_data(path):
    df = pd.read_csv(path)
    return df

# Load data
st.sidebar.header("📁 Data Source")
use_sample = st.sidebar.toggle("Use included sample dataset", value=True)
if use_sample:
    path = DEFAULT_FILE
else:
    up = st.sidebar.file_uploader("Upload your HR CSV", type=["csv"])
    if up:
        path = up
    else:
        st.stop()

df = load_data(path)
df = df.dropna(subset=["Attrition", "JobRole", "JobSatisfaction"])
df["_Attr01"] = df["Attrition"].map({"Yes":1, "No":0})

# Filters
st.sidebar.header("🔎 Filters")
roles = st.sidebar.multiselect("Select Job Roles", df["JobRole"].unique(), default=list(df["JobRole"].unique()))
sat_range = st.sidebar.slider("Job Satisfaction", int(df["JobSatisfaction"].min()), int(df["JobSatisfaction"].max()), (int(df["JobSatisfaction"].min()), int(df["JobSatisfaction"].max())))

filtered = df[df["JobRole"].isin(roles)]
filtered = filtered[(filtered["JobSatisfaction"] >= sat_range[0]) & (filtered["JobSatisfaction"] <= sat_range[1])]
st.caption(f"Filtered rows: {len(filtered)} / {len(df)}")

tab1, tab2, tab3 = st.tabs(["📊 Insights Dashboard", "🤖 Modeling", "📤 Predict New Data"])

# -------------------- Tab 1 --------------------
with tab1:
    st.subheader("1️⃣ Attrition Rate by Job Role")
    fig, ax = plt.subplots()
    rate = filtered.groupby("JobRole")["_Attr01"].mean().sort_values(ascending=False)
    sns.barplot(x=rate.values, y=rate.index, ax=ax, palette="coolwarm")
    ax.set_xlabel("Attrition Rate")
    st.pyplot(fig)

    st.subheader("2️⃣ Job Satisfaction vs Monthly Income (Attrition Color)")
    if {"MonthlyIncome","JobSatisfaction"}.issubset(filtered.columns):
        fig, ax = plt.subplots()
        sns.scatterplot(data=filtered, x="JobSatisfaction", y="MonthlyIncome", hue="Attrition", ax=ax)
        st.pyplot(fig)

    st.subheader("3️⃣ Correlation Heatmap (Numeric Columns)")
    num_cols = filtered.select_dtypes(include=np.number)
    fig, ax = plt.subplots(figsize=(8,5))
    sns.heatmap(num_cols.corr(), annot=True, cmap="coolwarm", ax=ax)
    st.pyplot(fig)

    st.subheader("4️⃣ OverTime vs Attrition by Job Role")
    if {"OverTime","Attrition"}.issubset(filtered.columns):
        fig, ax = plt.subplots(figsize=(8,5))
        sns.countplot(data=filtered, x="JobRole", hue="OverTime", ax=ax)
        plt.xticks(rotation=45)
        st.pyplot(fig)

    st.subheader("5️⃣ Attrition Rate by Tenure Cohorts")
    if "YearsAtCompany" in filtered.columns:
        filtered["TenureGroup"] = pd.cut(filtered["YearsAtCompany"], bins=[-1,1,3,5,8,12,40], labels=["<=1","2-3","4-5","6-8","9-12","13+"])
        rate = filtered.groupby("TenureGroup")["_Attr01"].mean()
        fig, ax = plt.subplots()
        rate.plot(kind="line", marker="o", ax=ax)
        ax.set_ylabel("Attrition Rate")
        st.pyplot(fig)

# -------------------- Tab 2 --------------------
with tab2:
    st.subheader("Train Models — Decision Tree, Random Forest, Gradient Boosting")
    run = st.button("▶️ Train Models")
    if run:
        X = filtered.drop(columns=["Attrition","_Attr01","EmployeeID"], errors="ignore")
        y = filtered["_Attr01"]
        cat_cols = [c for c in X.columns if X[c].dtype=="O"]
        num_cols = [c for c in X.columns if c not in cat_cols]
        pre = ColumnTransformer([
            ("cat", Pipeline([("imp", SimpleImputer(strategy="most_frequent")),("oh",OneHotEncoder(handle_unknown="ignore"))]), cat_cols),
            ("num", Pipeline([("imp",SimpleImputer(strategy="median"))]), num_cols)
        ])
        models = {
            "Decision Tree": DecisionTreeClassifier(random_state=42),
            "Random Forest": RandomForestClassifier(n_estimators=200, random_state=42),
            "Gradient Boosting": GradientBoostingClassifier(random_state=42)
        }
        res = []
        for name, model in models.items():
            pipe = Pipeline([("pre",pre),("clf",model)])
            X_train, X_test, y_train, y_test = train_test_split(X,y,test_size=0.3,random_state=42,stratify=y)
            pipe.fit(X_train,y_train)
            y_pred = pipe.predict(X_test)
            y_prob = pipe.predict_proba(X_test)[:,1]
            m = {
                "Model": name,
                "Accuracy": accuracy_score(y_test,y_pred),
                "Precision": precision_score(y_test,y_pred),
                "Recall": recall_score(y_test,y_pred),
                "F1": f1_score(y_test,y_pred),
                "AUC": roc_auc_score(y_test,y_prob)
            }
            res.append(m)
        st.dataframe(pd.DataFrame(res))

# -------------------- Tab 3 --------------------
with tab3:
    st.subheader("Upload and Predict")
    file = st.file_uploader("Upload CSV", type=["csv"])
    if file:
        new_df = pd.read_csv(file)
        base = filtered.copy()
        y = base["_Attr01"]
        X = base.drop(columns=["Attrition","_Attr01","EmployeeID"], errors="ignore")
        pre = ColumnTransformer([
            ("cat", Pipeline([("imp", SimpleImputer(strategy="most_frequent")),("oh",OneHotEncoder(handle_unknown="ignore"))]), [c for c in X.columns if X[c].dtype=="O"]),
            ("num", Pipeline([("imp", SimpleImputer(strategy="median"))]), [c for c in X.columns if X[c].dtype!="O"])
        ])
        model = GradientBoostingClassifier(random_state=42)
        pipe = Pipeline([("pre", pre), ("clf", model)])
        pipe.fit(X, y)
        preds = pipe.predict(new_df)
        probs = pipe.predict_proba(new_df)[:,1]
        new_df["Attrition_Pred"] = np.where(preds==1, "Yes", "No")
        new_df["Attrition_Prob"] = probs
        st.dataframe(new_df.head())
        st.download_button("⬇️ Download predictions", new_df.to_csv(index=False).encode(), "predictions.csv", "text/csv")
