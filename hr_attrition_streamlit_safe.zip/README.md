
# HR Attrition Intelligence — Streamlit App (Safe Matplotlib Version)

This is a fallback version using only **Streamlit + Matplotlib** (no Plotly) to ensure full compatibility on Streamlit Cloud.

## Files
- app.py
- requirements.txt
- hr_sample_attrition.csv
- README.md

## Deploy on Streamlit Cloud
1. Upload these 4 files to your GitHub repository **root**.
2. Set `app.py` as the entry point.
3. Streamlit Cloud will automatically install the dependencies and run.

## Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```
